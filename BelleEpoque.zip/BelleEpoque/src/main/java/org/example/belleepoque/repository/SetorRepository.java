package org.example.belleepoque.repository;


import org.example.belleepoque.model.Setor;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SetorRepository extends JpaRepository<Setor, Long> {

}
