package org.example.belleepoque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelleEpoqueApplicationTests {

    @Test
    void contextLoads() {
    }

}
